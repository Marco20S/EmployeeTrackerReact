import React from "react"
import { useState } from "react"

let EmpID = 0;

export default function EmployeeInfo(props) {


    const [name, setName] = useState('');
    const [idnumber, setIdnumber] = useState('');
    const [mail, setMail] = useState('');
    const [eposition, setEposition] = useState('');
    const [phone, setPhone] = useState('');
    const [image, setImage] = useState('');
    // const [employee, setEmployee] = useState({name: '', idnumber: '', mail: '', eposition: "", phone: ""});
    const [index,setIndex] = useState(1)
    
    //test
    // const [student, setStudent] = useState(["john", "cena"])

    // const addUser = (event) =>{
    //     event.preventDefault();
    //     setEmployee(currentEmployee => [...currentEmployee, name]); 
    //     setEmployee('');

    // }

    // const addUserq = (event) =>{
    //     event.preventDefault();
    //     setEmployee(currentStudent => [...currentStudent, name]); 
    //     setStudent('');
    //     console.log();
    // }

   

    function addEmployee(e) {
        e.preventDefault();
        // setEmployee({name: name, idnumber: idnumber, mail: mail, eposition: eposition, phone: phone})
        // console.log(employee);
        const temp = {name: name, idnumber: idnumber, mail: mail, eposition: eposition, phone: phone};
        props.add(temp);
        console.log('Info.js',props.employees);
        setIndex(index + 1);

    }

    // function ChangInfo(e) {
    // }

    // const deleteEmployee = (deleteEmp) => {
    //     // alert(EmployeeInfo)
    //     const newDelete = employee.filter((employee) => employee !== deleteEmp);
    //     setEmployee(newDelete)
    // }
    // const add = (() => {
    //     props.add(name, idnumber, mail, eposition, phone)

    // })

    return (
        <>
            <form onSubmit={addEmployee}>

                <h1> Employee App</h1>

                <p>Please enter the Employee's following details  </p>

                <label className="NS">Name And Surname</label>
                <br />
                <input type="text" className="name" value={name} placeholder="Example: Senzo Meyiwa" name="name"
                    onChange={(event) => setName(event.target.value)} />

                <br />

                <label className="NS">ID Number</label>
                <br />
                <input type="text" value={idnumber} className="IDNumber" placeholder="Example: 0011056756081" name="idnumber"
                    onChange={(event) => setIdnumber(event.target.value)} />

                <br />

                <label className="NS">Email</label>
                <br />
                <input type="email" value={mail} className="mail" placeholder="Example: Senzo@gmail.com" name="mail"
                    onChange={(event) => setMail(event.target.value)} />

                <br />

                <label className="NS">Employee Position</label>
                <br />
                <input type="text" value={eposition} className="mail" placeholder="Example: HR" name="eposition"
                    onChange={(event) => setEposition(event.target.value)} />


                <br />


                <label className="NS">Phone Number</label>
                <br />
                <input type="text" value={phone} className="phone" placeholder="Example: 0112233445" name="phone"
                    onChange={(event) => setPhone(event.target.value)} />

                <br />

                <label className="NS">Insert Image</label>
                <br />
                <input type="image" value={image} className="image" placeholder="Image" name="image"
                    onChange={(event) => setImage(event.target.value)} />


                <br />

                <div className="button-group">

                    <button type="submit" className="button">Add Profile</button>

                    <button className="button" >Update Profile</button>

                    <button className="button"  >Delete Profile</button>

                </div>

            </form>


            {/* // displaying database  */}

            <h1>Employee list</h1>

            <ul>
                {
                    // props.student.map((students, index) => <li key={index}>{students}</li>)
                    // props.EmployeeInfo.map((employees,index)<li key={index}>{employees}</li>)
                    // props.employees.map((employee) => <li key={index}> {employee}</li>)
                }

            </ul>

        </>
    )
}