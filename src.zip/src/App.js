import { useState } from 'react';

import './App.css';
import EmployeeInfo from './components/EmployeeInfo';
import Employeess from './components/EmployeeInfo';

function App() {


  const [employees, setEmployees] = useState([])
  
  const add= ((emp) => {

    setEmployees(()=>[...employees,{name: emp.name, idnumber: emp.idnumber, 
      mail:emp.mail, eposition:emp.eposition, phone:emp.phone}])

      console.log('App.js',employees)
  })



  return (
    <div className='Ye' >

      <EmployeeInfo add = {add} employees= {employees}/>

    </div>
  );
}

export default App;
