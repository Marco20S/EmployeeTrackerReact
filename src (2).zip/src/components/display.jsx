import React from "react"



export default function DisplayEmployee(props) {
    return (

        <>

            <h1>Employee list</h1>

            <ul>
                {
                    // props.student.map((students, index) => <li key={index}>{students}</li>)
                    // props.EmployeeInfo.map((employees,index)<li key={index}>{employees}</li>)
                    

                }

            </ul>

        </>

    )
}